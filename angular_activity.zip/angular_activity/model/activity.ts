export class Activity {
    id:number;
    name:string;
    price:number;
    brand:string;

}
