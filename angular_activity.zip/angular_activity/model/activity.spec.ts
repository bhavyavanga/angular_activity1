import { Activity } from './activity';

describe('Activity', () => {
  it('should create an instance', () => {
    expect(new Activity()).toBeTruthy();
  });
});
