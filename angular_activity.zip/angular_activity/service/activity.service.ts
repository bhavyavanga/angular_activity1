import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Activity } from '../model/activity';

@Injectable({
  providedIn: 'root'
})
export class ActivityService {
  url:string="http://localhost:2300/products";
  filtereddata:Activity[];
  constructor(private http:HttpClient) { }
  
  addProduct(product:Activity){
    return this.http.post(this.url,product);
      }

      getAllProducts(){
        return this.http.get<Activity[]>(this.url);
      }
    
      deleteProduct(product:Activity){
        return this.http.delete<Activity[]>(this.url+"/"+product.id);
      }
      getProduct(id:number){
        return this.http.get<Activity>(this.url+"/"+id);
      }
      setSearcheddata(searchedData:Activity[]){
        this.filtereddata=searchedData;
         }
         getSearchedData(){
         return this.filtereddata;
         }
     
}
