import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './component/show/show.component';
import { SearchComponent } from './component/search/search.component';
import { AddComponent } from './component/add/add.component';
import { ShowsearcheddataComponent } from './component/showsearcheddata/showsearcheddata.component';


const routes: Routes = [
  {path:'',redirectTo:'show',pathMatch:'full'},
  {path:'show',component : ShowComponent},
  {path:'search',component : SearchComponent},
  {path:'add',component : AddComponent},
  {path:'showsearcheddata',component : ShowsearcheddataComponent}
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
