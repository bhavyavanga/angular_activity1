import { Component, OnInit } from '@angular/core';
import { Activity } from 'src/app/model/activity';
import { ActivityService } from 'src/app/service/activity.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  products:Activity[];

  constructor(private productService:ActivityService) { }

  ngOnInit() {
    this.productService.getAllProducts().subscribe(
      (data:Activity[])=>{this.products=data
       console.log("all"+this.products)});
  }

  deleteProduct(product:Activity){
    this.productService.deleteProduct(product).subscribe(
(data)=>{this.products=this.products.filter(product=>product!==product)}
    );
  }

}
