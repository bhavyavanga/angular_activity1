import { Component, OnInit } from '@angular/core';
import { Activity } from 'src/app/model/activity';
import { ActivityService } from 'src/app/service/activity.service';

@Component({
  selector: 'app-showsearcheddata',
  templateUrl: './showsearcheddata.component.html',
  styleUrls: ['./showsearcheddata.component.css']
})
export class ShowsearcheddataComponent implements OnInit {

  searchedData:Activity[];
 
  constructor(private service:ActivityService) { }
  
  ngOnInit() {
  this.searchedData=this.service.getSearchedData();
  }

}
