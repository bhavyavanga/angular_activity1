import { Component, OnInit } from '@angular/core';
import { Activity } from 'src/app/model/activity';
import { ActivityService } from 'src/app/service/activity.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  products:Activity[];
  searchItem:string='';
  searchedData:Activity[];
    constructor(private service:ActivityService) { }
  
    ngOnInit() {
      this.service.getAllProducts().subscribe(
        (data:Activity[])=>{this.products=data;
        console.log("all"+this.products)});
    }
    search(value:string){
      this.searchedData=this.products.filter(
        product=>product.name.toLowerCase().
        indexOf(value.toLowerCase())!=-1);
  this.service.setSearcheddata(this.searchedData);
  
  
    }
  
}
